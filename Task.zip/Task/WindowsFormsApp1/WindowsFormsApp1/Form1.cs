﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography.X509Certificates;

namespace Loginform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            /*
            string file = "C:/Users/Razvan/Desktop/Atestat Info/Vineri/IEatCoochie/node/security/rootCA.pem"; // Contains name of certificate file
            X509Store store = new X509Store(StoreName.Root, StoreLocation.LocalMachine);
            store.Open(OpenFlags.ReadWrite);
            store.Add(new X509Certificate2(X509Certificate2.CreateFromCertFile(file)));
            store.Close();
            */

        }


        public class RootObject
        {
            public int id { get; set; }
            public string username { get; set; }
            public string password { get; set; }
            public int admin { get; set; }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }


        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Login cancelled", " ", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string user = textBox1.Text;
            string pass = textBox2.Text;
            string html = string.Empty;
            string url = @"https://localhost:8080/searchu?username=" + textBox1.Text;

           // try
           // {
                
            //try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.AutomaticDecompression = DecompressionMethods.GZip;
                using (HttpWebResponse response = (HttpWebResponse) request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    html = reader.ReadToEnd();
                }
                Console.WriteLine(html);
                if (html == "Baza de date offline")
                {
                    MessageBox.Show("Baza de date este offline");
                }
                else
                {
                    RootObject obj;
                    var resultscan = JsonConvert.DeserializeObject<List<RootObject>>(html);
                    obj = resultscan[0];

                    if (obj.admin == 1)
                    {
                        using (Form2 f2 = new Form2())
                        {
                            this.Hide();
                            f2.ShowDialog(this);
                            this.Close();
                        }
                    }
                    else
                    {
                        using (Form3 f3 = new Form3())
                        {
                            this.Hide();
                            f3.ShowDialog(this);
                            this.Close();
                        }
                    }
                }
            }
           // catch { MessageBox.Show("Serverul este oprit"); }
                
                }
           // } catch
           // {
            //    MessageBox.Show("Serverul este oprit");
           // }

        

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_2(object sender, EventArgs e)
        {

        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            if(textBox1.Text=="Username")
            {
                textBox1.Text = "";
                textBox1.ForeColor = Color.Black;
            }
        }
        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Username";
                textBox1.ForeColor = Color.Silver;
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            if (textBox2.Text == "Password")
            {
                textBox2.Text = "";
                textBox2.ForeColor = Color.Black;
            }
        }
        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                textBox2.Text = "Password";
                textBox2.ForeColor = Color.Silver;
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                button1.PerformClick();
            }
        }
    }
}
